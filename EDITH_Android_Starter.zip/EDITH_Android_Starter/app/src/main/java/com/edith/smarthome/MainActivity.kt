package com.edith.smarthome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Cyan = Color(0xFF65E7F2)
private val Muted = Color(0xFF9AAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EdithApp() }
    }
}

private data class Relay(val title: String, val room: String, val icon: ImageVector, val on: Boolean = false)

@Composable
fun EdithApp() {
    var tab by remember { mutableStateOf(0) }
    var relays by remember {
        mutableStateOf(listOf(
            Relay("Main Light", "Living room", Icons.Default.Lightbulb),
            Relay("Fan", "Bedroom", Icons.Default.Air),
            Relay("Night Lamp", "Bedroom", Icons.Default.Bedtime),
            Relay("Outdoor", "Porch", Icons.Default.WbTwilight)
        ))
    }
    var master by remember { mutableStateOf(false) }
    var brightness by remember { mutableFloatStateOf(0.72f) }
    var effect by remember { mutableStateOf("Aurora") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF101D31), Bg, Color(0xFF080B13)))
        )) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Cyan, Color(0xFF6477FF)))),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bolt, null, tint = Bg, modifier = Modifier.size(27.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("E.D.I.T.H.", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("HOME INTELLIGENCE", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF153B3A), shape = CircleShape) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF58E6B0)))
                            Spacer(Modifier.width(6.dp))
                            Text("ONLINE", color = Color(0xFF8CF0C9), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                when (tab) {
                    0 -> HomeScreen(relays, master, { master = it; relays = relays.map { r -> r.copy(on = it) } },
                        { index, value -> relays = relays.toMutableList().also { it[index] = it[index].copy(on = value) } })
                    1 -> PixelScreen(brightness, { brightness = it }, effect, { effect = it })
                    else -> SettingsScreen()
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Color(0xDD101827), contentColor = Muted) {
                    val labels = listOf("Home", "Pixel Studio", "Settings")
                    val icons = listOf(Icons.Default.Home, Icons.Default.AutoAwesome, Icons.Default.Settings)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF1C3445), unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            ))
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun HomeScreen(relays: List<Relay>, master: Boolean, onMaster: (Boolean) -> Unit, onRelay: (Int, Boolean) -> Unit) {
    Column {
        Text("Good day, Sir.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Your home is looking good.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("DEVICE", "EDITH Core", Icons.Default.Memory, Modifier.weight(1f))
            StatCard("NETWORK", "Wi-Fi linked", Icons.Default.Wifi, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFF172B3B),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF315363), RoundedCornerShape(22.dp))
        ) {
            Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MASTER CONTROL", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text(if (master) "Everything is ON" else "Everything is OFF", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Switch(checked = master, onCheckedChange = onMaster)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Your devices", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("${relays.count { it.on }} / 4 ACTIVE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(270.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(relays) { relay ->
                val index = relays.indexOf(relay)
                RelayCard(relay) { onRelay(index, !relay.on) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Surface(color = Color(0xFF111C2B), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Mic, null, tint = Cyan)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("EDITH voice assistant", fontWeight = FontWeight.SemiBold)
                    Text("Say “Edith” in the connected app to begin", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector, modifier: Modifier) {
    Surface(modifier, color = Color(0xFF111B2B), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(9.dp))
            Column {
                Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RelayCard(relay: Relay, onClick: () -> Unit) {
    Surface(color = if (relay.on) Color(0xFF173344) else Color(0xFF111B2A),
        shape = RoundedCornerShape(19.dp),
        modifier = Modifier.fillMaxWidth().height(124.dp).border(1.dp,
            if (relay.on) Color(0xFF3C9BA8) else Color(0xFF243247), RoundedCornerShape(19.dp))
            .clickable { onClick() }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(relay.icon, null, tint = if (relay.on) Cyan else Muted, modifier = Modifier.size(23.dp))
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (relay.on) Cyan else Color(0xFF536174)))
            }
            Column {
                Text(relay.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(if (relay.on) "ON  •  ${relay.room}" else "OFF  •  ${relay.room}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun PixelScreen(brightness: Float, onBrightness: (Float) -> Unit, effect: String, onEffect: (String) -> Unit) {
    Column {
        Text("Pixel Studio", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Create the atmosphere you want.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))
        Surface(color = Color(0xFF142538), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().height(165.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    repeat(12) { i ->
                        Box(Modifier.width(13.dp).height((35 + (i % 4) * 19).dp).clip(CircleShape)
                            .background(listOf(Cyan, Color(0xFF7D85FF), Color(0xFFDF79E8))[i % 3]))
                    }
                }
                Text("50 LED • WS2812B", modifier = Modifier.align(Alignment.BottomCenter).padding(14.dp),
                    color = Color.White, fontSize = 10.sp, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("LIGHT EFFECT", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(9.dp))
        val effects = listOf("Aurora", "Rainbow", "Fire", "Pulse", "Ocean", "Solid")
        effects.chunked(3).forEach { line ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                line.forEach { item ->
                    FilterChip(selected = effect == item, onClick = { onEffect(item) }, label = { Text(item) })
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Brightness  ${(brightness * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
        Slider(value = brightness, onValueChange = onBrightness)
        Text("Presets and live LED control will connect after the ESP32 API is added.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingsScreen() {
    Column {
        Text("Settings", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Personalise your EDITH system.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        SettingRow(Icons.Default.Router, "ESP32 connection", "Set device IP address")
        SettingRow(Icons.Default.Edit, "Device names", "Rename your four relays")
        SettingRow(Icons.Default.RecordVoiceOver, "Voice assistant", "Wake phrase: Edith")
        SettingRow(Icons.Default.Language, "Language", "English • Malayalam")
        SettingRow(Icons.Default.Info, "About EDITH", "Home Intelligence • v1.0")
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, subtitle: String) {
    Surface(color = Color(0xFF111B2A), shape = RoundedCornerShape(17.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan)
            Spacer(Modifier.width(13.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}
