# EDITH Android Starter

A dark glass-style Jetpack Compose starter for the EDITH smart-home app.

## Build on GitHub (phone-friendly)
1. Extract this ZIP.
2. Upload the **contents** of this folder into the root of your `EDITH-appoffical` repository (keep the `.github` folder).
3. Open **Actions** → **Build EDITH APK** → **Run workflow**.
4. When complete, open the workflow run and download the `EDITH-debug-APK` artifact.

## Important
This is the attractive UI starter, not a connected release app yet. Relay cards and Pixel Studio controls currently change on-screen demo state only. ESP32 HTTP API, Gemini backend, microphone permission/foreground wake-word service, persistent settings, and secure remote control still need integration and testing. Do not expose an unauthenticated ESP32 HTTP server to the public internet.
